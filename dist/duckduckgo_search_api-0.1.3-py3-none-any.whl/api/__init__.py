from .apiDDG import Duckduckgo

__all__ = ['Duckduckgo']